# تطبيق Smart FC للأندرويد

مشروع مبدئي يعرض https://www.smartfc-club.com داخل تطبيق Android باستخدام WebView.

## بناء APK عبر GitHub Actions (مناسب لجهاز Windows 8 32-bit)
1. أنشئ مستودعًا جديدًا على GitHub باسم `SmartFCAndroid` واجعله Private أو Public.
2. فك ضغط ملف ZIP على جهازك.
3. افتح المستودع ثم اختر **Add file > Upload files**.
4. ارفع محتويات مجلد `SmartFCAndroid` نفسها (بما فيها مجلد `.github`)، وليس ملف ZIP فقط. يجب أن يكون `app`, `build.gradle`, `settings.gradle` و`.github` في جذر المستودع.
5. اضغط **Commit changes**.
6. افتح تبويب **Actions**. اختر سير العمل **Build Smart FC APK** ثم **Run workflow** إذا لم يبدأ تلقائيًا بعد الرفع.
7. انتظر حتى تنتهي العملية بنجاح، ثم افتح عملية البناء الناجحة وانزل إلى **Artifacts**.
8. نزّل `SmartFC-debug-APK` وفك ضغطه؛ ستجد `app-debug.apk`.
9. انقل APK إلى هاتف Android وثبّته بعد السماح بالتثبيت من هذا المصدر عند الطلب.

## متطلبات البناء السحابي
يستخدم GitHub Actions وUbuntu وJava 17 وGradle 8.9. لا تحتاج لتثبيت Android Studio على Windows 8 32-bit.

## ملاحظات مهمة
- هذا APK تجريبي (debug) للاختبار، وليس إصدارًا موقّعًا للنشر على Google Play.
- اختبر تسجيل الدخول والنماذج والروابط على الهاتف. قد تحتاج بعض وظائف WordPress، مثل رفع الملفات أو النوافذ المنبثقة أو الدفع، إلى معالجة إضافية.
- لا تضع كلمات مرور أو مفاتيح API سرية في المستودع.
